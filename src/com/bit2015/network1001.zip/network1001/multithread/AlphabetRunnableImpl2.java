package com.bit2015.network1001.multithread;

public class AlphabetRunnableImpl2 extends Alphabet implements Runnable{

	@Override
	public void run() {
		print();
		// TODO Auto-generated method stub
		
	}
	

}
